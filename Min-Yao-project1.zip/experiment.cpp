#include "activity_selection.h"
#include <iostream>
#include <fstream>
#include <chrono>
#include <iomanip>

using namespace std;
using namespace std::chrono;

/**
 * Measure execution time of activity selection algorithm
 * 
 * @param n Number of activities
 * @param maxTime Maximum time range for activities
 * @return Execution time in microseconds
 */
double measureExecutionTime(int n, int maxTime) {
    // Generate random activities
    vector<Activity> activities = generateRandomActivities(n, maxTime);
    
    // Measure execution time
    auto start = high_resolution_clock::now();
    vector<Activity> selected = activitySelection(activities);
    auto end = high_resolution_clock::now();
    
    // Calculate duration in microseconds
    auto duration = duration_cast<microseconds>(end - start);
    
    return duration.count();
}

/**
 * Run experiments with different input sizes
 */
void runExperiments() {
    cout << "Running Activity Selection Experiments...\n";
    cout << "==========================================\n\n";
    
    // Test sizes
    vector<int> testSizes = {
        100, 200, 500, 1000, 2000, 3000, 5000, 
        7000, 10000, 15000, 20000, 30000, 50000
    };
    
    // Open file to save results
    ofstream outFile("results.csv");
    outFile << "n,time_microseconds,time_milliseconds\n";
    
    cout << left << setw(15) << "Input Size (n)" 
         << setw(20) << "Time (microseconds)" 
         << setw(20) << "Time (milliseconds)"
         << setw(20) << "Selected Activities" << "\n";
    cout << string(75, '-') << "\n";
    
    for (int n : testSizes) {
        // Run multiple times and take average
        const int RUNS = 5;
        double totalTime = 0;
        int selectedCount = 0;
        
        for (int run = 0; run < RUNS; run++) {
            vector<Activity> activities = generateRandomActivities(n, n * 10);
            
            auto start = high_resolution_clock::now();
            vector<Activity> selected = activitySelection(activities);
            auto end = high_resolution_clock::now();
            
            auto duration = duration_cast<microseconds>(end - start);
            totalTime += duration.count();
            selectedCount = selected.size();
        }
        
        double avgTime = totalTime / RUNS;
        double avgTimeMs = avgTime / 1000.0;
        
        // Print results
        cout << left << setw(15) << n 
             << setw(20) << fixed << setprecision(2) << avgTime
             << setw(20) << avgTimeMs
             << setw(20) << selectedCount << "\n";
        
        // Save to file
        outFile << n << "," << avgTime << "," << avgTimeMs << "\n";
    }
    
    outFile.close();
    
    cout << "\n==========================================\n";
    cout << "Results saved to 'results.csv'\n";
    cout << "Run 'python plot_results.py' to generate graphs\n";
}

/**
 * Demo with a small example
 */
void runDemo() {
    cout << "\n\n=== DEMO: Activity Selection Example ===\n\n";
    
    // Create a small set of activities
    vector<Activity> activities = {
        Activity(1, 4, 0),   // Activity 0: [1, 4]
        Activity(3, 5, 1),   // Activity 1: [3, 5]
        Activity(0, 6, 2),   // Activity 2: [0, 6]
        Activity(5, 7, 3),   // Activity 3: [5, 7]
        Activity(3, 9, 4),   // Activity 4: [3, 9]
        Activity(5, 9, 5),   // Activity 5: [5, 9]
        Activity(6, 10, 6),  // Activity 6: [6, 10]
        Activity(8, 11, 7),  // Activity 7: [8, 11]
        Activity(8, 12, 8),  // Activity 8: [8, 12]
        Activity(2, 14, 9),  // Activity 9: [2, 14]
        Activity(12, 16, 10) // Activity 10: [12, 16]
    };
    
    cout << "Input Activities:\n";
    cout << left << setw(15) << "Activity ID" 
         << setw(15) << "Start Time" 
         << setw(15) << "Finish Time" << "\n";
    cout << string(45, '-') << "\n";
    
    for (const auto& a : activities) {
        cout << left << setw(15) << a.id 
             << setw(15) << a.start 
             << setw(15) << a.finish << "\n";
    }
    
    // Run algorithm
    vector<Activity> selected = activitySelection(activities);
    
    cout << "\n\nSelected Activities (Maximum Non-Overlapping Set):\n";
    cout << left << setw(15) << "Activity ID" 
         << setw(15) << "Start Time" 
         << setw(15) << "Finish Time" << "\n";
    cout << string(45, '-') << "\n";
    
    for (const auto& a : selected) {
        cout << left << setw(15) << a.id 
             << setw(15) << a.start 
             << setw(15) << a.finish << "\n";
    }
    
    cout << "\nTotal selected: " << selected.size() << " activities\n";
    cout << "Total input: " << activities.size() << " activities\n";
}

int main() {
    // Run demo first
    runDemo();
    
    // Run experiments
    runExperiments();
    
    return 0;
}

