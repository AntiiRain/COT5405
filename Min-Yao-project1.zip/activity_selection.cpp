#include "activity_selection.h"
#include <random>

// Comparator to sort activities by finish time
bool compareByFinish(const Activity& a, const Activity& b) {
    return a.finish < b.finish;
}

/**
 * Activity Selection Algorithm using Greedy Approach
 * 
 * Algorithm:
 * 1. Sort activities by finish time (ascending)
 * 2. Select the first activity
 * 3. For each remaining activity:
 *    - If its start time >= last selected activity's finish time
 *    - Select it and update last finish time
 * 
 * Time Complexity: O(n log n) due to sorting
 * Space Complexity: O(n) for storing result
 * 
 * @param activities Vector of activities (will be sorted)
 * @return Vector of selected non-overlapping activities
 */
std::vector<Activity> activitySelection(std::vector<Activity>& activities) {
    std::vector<Activity> result;
    
    // Handle edge cases
    if (activities.empty()) {
        return result;
    }
    
    // Step 1: Sort by finish time - O(n log n)
    std::sort(activities.begin(), activities.end(), compareByFinish);
    
    // Step 2: Select first activity - O(1)
    result.push_back(activities[0]);
    int lastFinishTime = activities[0].finish;
    
    // Step 3: Greedily select compatible activities - O(n)
    for (size_t i = 1; i < activities.size(); i++) {
        // If current activity starts after or when the last selected one finishes
        if (activities[i].start >= lastFinishTime) {
            result.push_back(activities[i]);
            lastFinishTime = activities[i].finish;
        }
    }
    
    return result;
}

/**
 * Generate random activities for testing
 * 
 * @param n Number of activities to generate
 * @param maxTime Maximum time value for start/finish times
 * @return Vector of randomly generated activities
 */
std::vector<Activity> generateRandomActivities(int n, int maxTime) {
    std::vector<Activity> activities;
    
    // Random number generator
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> startDist(0, maxTime - 2);
    std::uniform_int_distribution<> durationDist(1, maxTime / 10);
    
    for (int i = 0; i < n; i++) {
        int start = startDist(gen);
        int duration = durationDist(gen);
        int finish = start + duration;
        
        // Ensure finish time doesn't exceed maxTime
        if (finish > maxTime) {
            finish = maxTime;
        }
        
        activities.push_back(Activity(start, finish, i));
    }
    
    return activities;
}

