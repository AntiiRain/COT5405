#ifndef ACTIVITY_SELECTION_H
#define ACTIVITY_SELECTION_H

#include <vector>
#include <algorithm>

// Structure to represent an activity
struct Activity {
    int start;
    int finish;
    int id;  // original index for tracking
    
    Activity(int s, int f, int i) : start(s), finish(f), id(i) {}
};

// Greedy algorithm for activity selection
// Returns vector of selected activities
std::vector<Activity> activitySelection(std::vector<Activity>& activities);

// Helper function to generate random activities for testing
std::vector<Activity> generateRandomActivities(int n, int maxTime);

#endif // ACTIVITY_SELECTION_H

