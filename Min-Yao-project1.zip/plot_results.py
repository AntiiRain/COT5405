#!/usr/bin/env python3
"""
Script to plot experimental results for Activity Selection Algorithm
Generates graphs showing the relationship between input size and running time
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def plot_results():
    # Read results from CSV
    df = pd.read_csv('results.csv')
    
    n = df['n'].values
    time_us = df['time_microseconds'].values
    time_ms = df['time_milliseconds'].values
    
    # Create figure with 2 subplots
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
    
    # Plot 1: Linear scale
    ax1.plot(n, time_ms, 'bo-', linewidth=2, markersize=8, label='Measured Time')
    ax1.set_xlabel('Input Size (n)', fontsize=12, fontweight='bold')
    ax1.set_ylabel('Time (milliseconds)', fontsize=12, fontweight='bold')
    ax1.set_title('Activity Selection: Running Time vs Input Size', fontsize=14, fontweight='bold')
    ax1.grid(True, alpha=0.3)
    ax1.legend()
    
    # Add O(n log n) theoretical curve
    # Normalize: find constant c such that c * n * log(n) fits the data
    theoretical = n * np.log2(n)
    c = np.mean(time_ms / theoretical)  # scaling constant
    ax1.plot(n, c * theoretical, 'r--', linewidth=2, label=f'O(n log n) theoretical (c={c:.4f})')
    ax1.legend()
    
    # Plot 2: Log-log scale to verify complexity
    ax2.loglog(n, time_ms, 'bo-', linewidth=2, markersize=8, label='Measured Time')
    ax2.loglog(n, c * theoretical, 'r--', linewidth=2, label='O(n log n) theoretical')
    ax2.set_xlabel('Input Size (n)', fontsize=12, fontweight='bold')
    ax2.set_ylabel('Time (milliseconds)', fontsize=12, fontweight='bold')
    ax2.set_title('Log-Log Plot: Verifying O(n log n) Complexity', fontsize=14, fontweight='bold')
    ax2.grid(True, alpha=0.3, which='both')
    ax2.legend()
    
    plt.tight_layout()
    plt.savefig('runtime_analysis.png', dpi=300, bbox_inches='tight')
    print("Graph saved as 'runtime_analysis.png'")
    
    # Create a second figure for ratio analysis
    fig2, ax3 = plt.subplots(figsize=(10, 6))
    
    # Calculate T(n) / (n log n) ratio
    ratio = time_us / (n * np.log2(n))
    ax3.plot(n, ratio, 'go-', linewidth=2, markersize=8)
    ax3.set_xlabel('Input Size (n)', fontsize=12, fontweight='bold')
    ax3.set_ylabel('T(n) / (n log n)', fontsize=12, fontweight='bold')
    ax3.set_title('Ratio Analysis: T(n) / (n log n) Should Be Approximately Constant', fontsize=14, fontweight='bold')
    ax3.grid(True, alpha=0.3)
    ax3.axhline(y=np.mean(ratio), color='r', linestyle='--', linewidth=2, label=f'Mean = {np.mean(ratio):.2f}')
    ax3.legend()
    
    plt.tight_layout()
    plt.savefig('ratio_analysis.png', dpi=300, bbox_inches='tight')
    print("Graph saved as 'ratio_analysis.png'")
    
    # Print statistics
    print("\n" + "="*50)
    print("EXPERIMENTAL RESULTS SUMMARY")
    print("="*50)
    print(f"Input size range: {n.min()} to {n.max()}")
    print(f"Time range: {time_ms.min():.2f} ms to {time_ms.max():.2f} ms")
    print(f"\nRatio T(n)/(n log n):")
    print(f"  Mean: {np.mean(ratio):.4f}")
    print(f"  Std Dev: {np.std(ratio):.4f}")
    print(f"  Min: {np.min(ratio):.4f}")
    print(f"  Max: {np.max(ratio):.4f}")
    print(f"\nThe approximately constant ratio confirms O(n log n) complexity!")
    print("="*50)
    
    # Show plots
    plt.show()

if __name__ == '__main__':
    plot_results()

